import asyncio
import pygame
import random
import time
# You can stand and then split
pygame.init()    

random.seed(time.time())

class CardManager:
    def __init__(self, y_offset=0):
        self.player_cards = []
        self.dealer_cards = []
        self.y_offset = y_offset
        self.font = pygame.font.Font("deltarune.ttf", 64)

    @property
    def player_value(self):
        value = 0
        ace_count = 0

        for card in self.player_cards:
            if card.num == 14:  # Ace
                value += 11
                ace_count += 1
            elif card.num >= 10:  # jack, Queen, King, 10
                value += 10
            else:
                value += card.num

        # If busted, convert Aces from 11 to 1
        while value > 21 and ace_count > 0:
            value -= 10
            ace_count -= 1
        return value

    @property
    def dealer_value(self):
        value = 0
        ace_count = 0

        for card in self.dealer_cards:
            if not card.flipped:
                if card.num == 14:  # Ace
                    value += 11
                    ace_count += 1
                elif card.num >= 10:  # jack, Queen, King, 10
                    value += 10
                else:
                    value += card.num

        # If busted, convert Aces from 11 to 1
        while value > 21 and ace_count > 0:
            value -= 10
            ace_count -= 1
        return value

    @property
    def dealer_busted(self):
        return self.dealer_value > 21

    @property
    def player_busted(self):
        return self.player_value > 21

    def add_dealer_card(self, card: "Card"):
        width = (len(self.dealer_cards) + 0.5) * 131
        left_card = 640 - width
        if self.dealer_cards:
            for dard in self.dealer_cards:
                dard.rect.left -= 131 / 2
            card.rect.topleft = self.dealer_cards[-1].rect.topright
        else:
            card.rect.top = 0
            card.rect.left = left_card
        self.dealer_cards.append(card)

    def add_player_card(self, card: "Card"):
        width = (len(self.player_cards) + 0.5) * 131
        left_card = 640 - width + self.y_offset
        if self.player_cards:
            for pard in self.player_cards:
                pard.rect.left -= 131 / 2
            card.rect.topleft = self.player_cards[-1].rect.topright
        else:
            card.rect.bottom = 720
            card.rect.left = left_card
        self.player_cards.append(card)

    def splittableee(self) -> bool:
        if len(self.player_cards) == 2 and self.player_cards[0].value == self.player_cards[1].value:
            return True
        else:
            return False

    def shift_cards(self, shift: int) -> None:
        self.y_offset += shift
        if self.player_cards:
            card = self.grab_card(0)
            self.add_player_card(card)
            
    def draw_player_value(self, screen):
        if self.player_value > 0:
            player_total_display = self.font.render(
                str(self.player_value), True, (255, 255, 255)
            )
            textpos = player_total_display.get_rect(center=(648 + self.y_offset, 480))
            screen.blit(player_total_display, textpos)
        if self.dealer_value > 0:
            dealer_total_display = self.font.render(
                str(self.dealer_value), True, (255, 255, 255)
            )
            textpos_dealer = dealer_total_display.get_rect(center=(648, 240))
            screen.blit(dealer_total_display, textpos_dealer)

    def grab_card(self, index: int) -> 'Card':
        card = self.player_cards.pop(index)
        return card

    def run_dealer_turn(self, deck: "Deck"):
        for card in self.dealer_cards:
            if card.flipped:
                card.flip()
        while self.dealer_value <= 16:
            self.add_dealer_card(deck.draw_card())

    def remove_player_cards(self):
        old_cards = self.player_cards
        self.player_cards = []
        return old_cards
        
    def remove_cards(self):
        self.player_cards = []
        self.dealer_cards = []

    def draw_all(self, screen):
        for card in self.player_cards:
            card.draw(screen)
        for card in self.dealer_cards:
            card.draw(screen)
        self.draw_player_value(screen)

class Deck:
    def __init__(self, card_set: pygame.Surface):
        self.cards = []
        self.card_set = card_set
        self.back_image = card_set.subsurface(pygame.Rect(21, 21, 139, 187))
        self._generate_deck()

    def _generate_deck(self):
        self.cards = []
        for _ in range(2):
            for i, suit in enumerate(["hearts", "clubs", "diamond", "spades"]):
                for j in range(1, 14):
                    card_coordnate = (21 + (140 * j), 21 + (i * 188))
                    card_scanner = pygame.Rect(*card_coordnate, 139, 187)
                    current_card = self.card_set.subsurface(card_scanner)
                    self.cards.append(Card(suit, j + 1, current_card, self.back_image))

    def shuffle(self):
        random.shuffle(self.cards)

    def draw_card(self):
        if len(self.cards) > 0:
            return self.cards.pop()

class Card:
    def __init__(
        self,
        suit: str,
        num: int,
        img: pygame.Surface,
        back_img: pygame.Surface,
        flipped: bool = False,
    ):
        self.suit = suit
        self.num = num
        self.flipped = flipped
        self.back = back_img
        self.front = img
        self.w = 139
        if self.flipped:
            self.img = self.back
        else:
            self.img = self.front
        self.rect = self.img.get_rect()
        self._current_rect = pygame.FRect(*self.rect)
        self.edward = -5
        self.flipping = False

    def draw(self, screen):
        if self.flipping:
            if self.edward < 0:
                self.w += self.edward
                if self.w <= 6:
                    self.edward = 5
                    if self.flipped:
                        self.img = self.back
                    else:
                        self.img = self.front

            else:
                self.w += self.edward
                if self.w >= 139:
                    self.edward = -5
                    self.flipping = False

        front = pygame.transform.scale(self.img, (self.w, self.rect.height))
        self._current_rect.x += (self.rect.x - self._current_rect.x) / 20
        self._current_rect.y += (self.rect.y - self._current_rect.y) / 40
        screen.blit(
            front,
            pygame.Rect(
                self._current_rect.x - (self.w / 2) + (139 / 2),
                self._current_rect.y,
                self._current_rect.width,
                self._current_rect.height,
            ),
        )

    def flip(self, animate: bool = True):
        self.flipped = not self.flipped
        if not animate:
            self.flipping = False
            if self.flipped:
                self.img = self.back
            else:
                self.img = self.front
        else:
            self.flipping = True
        return self

    @property
    def value(self):
        if self.num >= 10:
            return 10
        if self.num == 14:
            return 11
        return self.num

class Button:
    def __init__(self, loaded_image):
        unscaled = pygame.image.load(loaded_image).convert_alpha()
        self.image = pygame.transform.scale_by(unscaled, 6)
        self.rect = self.image.get_frect(center=(1280 / 2, 720 / 1.5))
        self.target_rect = pygame.FRect(*self.rect)
        
    def is_clicked(self,event: pygame.Event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            return self.rect.collidepoint(event.pos)
        return False

    def go_to(self, x, y):
        self.target_rect.centerx = x
        self.rect.centery = y

    def draw(self, screen: pygame.Surface):
        self.rect.x += (self.target_rect.x - self.rect.x) / 5
        screen.blit(self.image, self.rect)

class Banner:
    def __init__(self, loaded_image):
        unscaled = pygame.image.load(loaded_image).convert_alpha()
        self.image = pygame.transform.scale_by(unscaled, 12)
        self.rect = self.image.get_frect(center=(1280 / 2, 2000))
        self.target_rect = pygame.FRect(*self.rect)
        self.target_rect.center = (1280 / 2, 720 / 1.5)

    def show(self, screen: pygame.Surface):
        self.rect.x += (self.target_rect.x - self.rect.x) / 10
        self.rect.y += (self.target_rect.y- self.rect.y) / 10
        screen.blit(self.image, self.rect)

    def hide(self, screen: pygame.Surface):
        self.rect.y += (1000 - self.rect.y) / 10
        screen.blit(self.image, self.rect)

async def main():
    
    screen = pygame.display.set_mode((1280, 720))
    pygame.display.set_caption("Blackjack( !! not a scam !! )")
    clock = pygame.time.Clock()

    manager = CardManager()
    splitager = CardManager()

    deck = Deck(pygame.image.load("card_set_bordered.png").convert_alpha())
    deck.shuffle()

    stand_button = Button("stand.png")
    hit_button = Button("hit.png")
    split_button = Button("split.png")

    win_banner = Banner("uwin.png")
    tie_banner = Banner("utie.png")
    los_banner = Banner("ulos.png")

    timer = 0
    game_time = 0
    reset = False

    running = True
    stand_button_pushed = False
    split_button_pushed = False
    dealerAI = False
    swap_hands = False
    splited = False
    split_swap_count = 0
    Turnover = False
    split_check_hand_2_trigger = 0

    def reset_game():
        nonlocal swap_hands, dealerAI, stand_button_pushed, reset, timer
        manager.remove_cards()
        splitager.remove_cards()
        swap_hands = False
        splited = False
        dealerAI = False
        stand_button_pushed = False
        reset = False
        timer = 0
        deck = Deck(pygame.image.load("card_set_bordered.png").convert_alpha())
        deck.shuffle()
        
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if hit_button.is_clicked(event) and not reset:
                manager.add_player_card(deck.draw_card())
                
            if stand_button.is_clicked(event) and not split_button_pushed and not reset:
                if swap_hands:
                    split_cards = splitager.remove_player_cards()
                    man_cards = manager.remove_player_cards()
                    man_dealer_cards = manager.dealer_cards
                    for card in split_cards:
                        manager.add_player_card(card)
                    for card in man_cards:
                        splitager.add_player_card(card)

                    # if we stand on a split, we should treat the next stand as a normal stand
                    swap_hands = False

                else:
                    # run dealer turn twice when we are splitting
                    stand_button_pushed = True
                    manager.run_dealer_turn(deck)
                    if splited:
                        split_check_hand_2_trigger = game_time + 7000
                    dealerAI = True

            
                
            if split_button.is_clicked(event) and not swap_hands and not stand_button_pushed:
                split_button_pushed = True
                card_add = manager.grab_card(-1)
                manager.shift_cards(-275)
                splitager.shift_cards(275)
                splitager.add_player_card(card_add)
                swap_hands = True
                splited = True

        if splited and split_check_hand_2_trigger != 0 and game_time >= split_check_hand_2_trigger:
            split_check_hand_2_trigger = 0
            timer = 0
            print("running split routine")
            split_cards = splitager.remove_player_cards()
            man_cards = manager.remove_player_cards()
            for card in split_cards:
                manager.add_player_card(card)
            for card in man_cards:
                splitager.add_player_card(card)
            manager.run_dealer_turn(deck)
            dealerAI = True         

        screen.fill((27, 107, 18))
        
        if not manager.dealer_cards:
            manager.add_player_card(deck.draw_card())
            manager.add_dealer_card(deck.draw_card().flip(animate=False))
            manager.add_player_card(deck.draw_card())
            manager.add_dealer_card(deck.draw_card())

        manager.draw_all(screen)
        splitager.draw_all(screen)

        stand_button.draw(screen)
        hit_button.draw(screen)

        if manager.splittableee() and not splited:
            split_button.draw(screen)
            split_button.go_to(640, 360)
            hit_button.go_to(320, 360)
            stand_button.go_to(960, 360)
        else:
            hit_button.go_to(420, 360)
            stand_button.go_to(860, 360)

        tie = (
            manager.dealer_value == manager.player_value
            and not manager.dealer_busted
            and dealerAI
        )
        if tie:
            if not reset:
                timer = 0
                reset = True
            if timer >= 3000:
                tie_banner.show(screen)
            if timer >= 6000:
                if splited:
                    tie_banner.hide(screen)
                else:
                    manager.remove_cards()
                    timer = 0
                    reset_game()


        win = dealerAI and  ( # not splitager.player_cards and
            (manager.player_value == 21 and manager.dealer_value != 21)
            or (
                manager.player_value > manager.dealer_value
                and not manager.player_busted
                and stand_button_pushed
            )
            or (not manager.player_busted and manager.dealer_busted)
        )
        if win:
            if not reset:
                timer = 0
                reset = True
            if timer >= 3000:
                win_banner.show(screen)
            if timer >= 6000:
                if splited:
                    win_banner.hide(screen)
                else:
                    manager.remove_cards()
                    timer = 0
                    reset_game()

        if not win and not tie and dealerAI:
            if not reset:
                timer = 0
                reset = True
            if timer >= 3000:
                los_banner.show(screen)

            if timer >= 6000:
                if splited:
                    los_banner.hide(screen)
                else:
                    manager.remove_cards()
                    timer = 0
                    reset_game()

        pygame.display.flip()
        await asyncio.sleep(0)
        dt = clock.tick(60)
        timer += dt
        game_time += dt

    pygame.quit()
if __name__ == "__main__":
    asyncio.run(main())